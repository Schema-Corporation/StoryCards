export interface ICards {
    id: number;
    imgCard: string;
    imgDescription?: string;
    imgRotate?: boolean;
}