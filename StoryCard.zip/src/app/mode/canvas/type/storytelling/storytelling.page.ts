import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-storytelling',
  templateUrl: './storytelling.page.html',
  styleUrls: ['./storytelling.page.scss'],
})
export class StorytellingPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
