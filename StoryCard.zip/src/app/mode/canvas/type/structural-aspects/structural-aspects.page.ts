import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-structural-aspects',
  templateUrl: './structural-aspects.page.html',
  styleUrls: ['./structural-aspects.page.scss'],
})
export class StructuralAspectsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
